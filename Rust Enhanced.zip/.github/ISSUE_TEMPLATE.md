### Sublime Text Version
E.g Sublime Text 3 (Build 3126)

### Rust Enhanced Version
In Sublime Text, go to `list packages` (ctrl|cmd + shift + p) and select Rust Enhanced to get the version

### Operating system
A good example is:
OS Name	Microsoft Windows 10 Pro
Version	10.0.14393 Build 14393

### Expected behavior
What should have happened?

### Actual behavior
What actually happened?

### Steps to reproduce
1.
2.
3.

### References
Are there any other GitHub issues (open or closed) that should be linked here?
For example:
- GH-1234
- ...
