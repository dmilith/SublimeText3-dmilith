fn main() {
    println!("ex1");
}
