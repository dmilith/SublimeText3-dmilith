fn main() {
    println!("ex2");
}
