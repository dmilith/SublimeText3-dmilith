
extern crate multi_targets;

use multi_targets::*;

fn main() {
    println!("Hello");
    libf1();
    lmod1::fmod1();
}
