fn main() {
    println!("altmain");
}

/*BEGIN*/fn warning_example() {
}/*END*/
// ~WARN function is never used
// ~NOTE(>=1.17.0) #[warn(dead_code)]
