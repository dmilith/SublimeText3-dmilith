#[path="common/helpers.rs"]
mod helpers;

#[test]
fn sample_test2() {
    helpers::helper();
}
