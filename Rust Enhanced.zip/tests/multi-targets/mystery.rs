// This is an example of a Rust file that does not belong to any target.
fn main() {
    println!("Hello Mystery");
}
