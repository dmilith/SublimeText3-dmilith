mod warning1;
mod warning2;

fn main() {
    unimplemented!();
}
