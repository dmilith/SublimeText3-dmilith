/*WARN 1 "examples/warning1.rs:1" " --> examples/warning1.rs:1:69"*/fn unused_a() {

}

/*WARN 2 "examples/warning1.rs:5" " --> examples/warning1.rs:5:69"*/fn unused_b() {

}
