fn main() {
}
// end-msg: WARN crate `SNAKE` should have a snake case
// end-msg: NOTE #[warn(non_snake_case)] on by default
