/*BEGIN*/fn main() {
}/*END*/
// ~NOTE(check) here is a function named 'main'
// ~NOTE(no-trans) function is never used
// ~NOTE(no-trans) #[warn(dead_code)]
