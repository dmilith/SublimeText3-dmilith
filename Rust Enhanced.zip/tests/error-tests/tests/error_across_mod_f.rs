/*BEGIN*/pub fn f() {
}/*END*/
// ~ERR defined here
