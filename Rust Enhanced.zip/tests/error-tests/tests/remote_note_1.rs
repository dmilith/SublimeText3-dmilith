#![deny(unreachable_code)]
//      ^^^^^^^^^^^^^^^^NOTE lint level defined here

pub mod remote_note_1_mod;
